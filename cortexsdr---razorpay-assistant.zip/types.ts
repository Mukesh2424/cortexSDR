export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  isStreaming?: boolean;
}

export interface LeadData {
  name: string;
  company: string;
  email: string;
  role: string;
  use_case: string;
  team_size: string;
  timeline: string;
}

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
  leadData: LeadData | null;
}