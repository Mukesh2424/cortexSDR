import { GoogleGenAI, Chat } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "../constants";

let chatSession: Chat | null = null;

export const initializeChat = () => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Create chat session with system instruction
  chatSession = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      temperature: 0.7, 
    },
  });

  return chatSession;
};

export const sendMessageStream = async (message: string) => {
  if (!chatSession) {
    initializeChat();
  }

  if (!chatSession) {
    throw new Error("Failed to initialize chat session");
  }

  return await chatSession.sendMessageStream({ message });
};

export const extractJsonFromText = (text: string): any | null => {
  const jsonRegex = /```json\s*([\s\S]*?)\s*```/;
  const match = text.match(jsonRegex);
  
  if (match && match[1]) {
    try {
      return JSON.parse(match[1]);
    } catch (e) {
      console.error("Failed to parse extracted JSON", e);
      return null;
    }
  }
  return null;
};

// Removes the JSON block from the text so it doesn't look ugly in the chat bubble
export const cleanResponseText = (text: string): string => {
   const jsonRegex = /```json\s*[\s\S]*?\s*```/;
   return text.replace(jsonRegex, '').trim();
}