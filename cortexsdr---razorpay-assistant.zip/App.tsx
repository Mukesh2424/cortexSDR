import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GenerateContentResponse } from "@google/genai";
import { Message, LeadData } from './types';
import { INITIAL_GREETING } from './constants';
import { initializeChat, sendMessageStream, extractJsonFromText, cleanResponseText } from './services/geminiService';

// --- Icons ---
const UserIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
);

const BotIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
);

const CheckIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500"><polyline points="20 6 9 17 4 12"></polyline></svg>
);

const MicIcon = ({ isListening }: { isListening: boolean }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill={isListening ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>
);

// Type definition for Web Speech API
interface IWindow extends Window {
  webkitSpeechRecognition: any;
  SpeechRecognition: any;
}

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { id: 'init', role: 'model', text: INITIAL_GREETING }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [leadData, setLeadData] = useState<LeadData | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const baseInputRef = useRef<string>(''); // Stores text before recording starts
  const isVoiceInteraction = useRef<boolean>(false); // Tracks if the current interaction was via voice

  // Initialize chat on mount
  useEffect(() => {
    initializeChat();
  }, []);

  // Initialize Speech Recognition
  useEffect(() => {
    const windowObj = window as unknown as IWindow;
    const SpeechRecognition = windowObj.SpeechRecognition || windowObj.webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true; // Keep listening until stopped manually
      recognition.interimResults = true; // Show results in real-time
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        window.speechSynthesis.cancel(); // Stop bot from talking if user interrupts
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.onresult = (event: any) => {
        // Flag that this input is coming from voice
        isVoiceInteraction.current = true;

        let transcript = '';
        // In continuous mode, we iterate over all results in the current session
        for (let i = 0; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        
        // Append new transcript to the base text that was there when we started
        const baseText = baseInputRef.current;
        const separator = (baseText && !baseText.endsWith(' ') && transcript) ? ' ' : '';
        setInputValue(baseText + separator + transcript);
      };

      recognition.onerror = (event: any) => {
        console.error("Speech recognition error", event.error);
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Handle Text-to-Speech for bot responses
  const speakResponse = (text: string) => {
    if (!window.speechSynthesis) return;

    // Remove JSON blocks and markdown characters for cleaner speech
    const cleanText = cleanResponseText(text).replace(/[*#_`]/g, '');
    if (!cleanText.trim()) return;

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'en-US';
    
    // Optional: Try to select a "Google US English" voice if available
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.name.includes('Google US English')) || voices.find(v => v.lang === 'en-US');
    if (preferredVoice) utterance.voice = preferredVoice;

    window.speechSynthesis.speak(utterance);
  };

  // Effect to trigger speech when a model message finishes loading
  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    
    // Check if it's a completed model message
    if (lastMessage?.role === 'model' && !lastMessage.isStreaming) {
      // Only speak if the user initiated this turn via voice
      if (isVoiceInteraction.current) {
        speakResponse(lastMessage.text);
      }
    }
  }, [messages]);

  const toggleListening = () => {
    if (!recognitionRef.current) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
    } else {
      // Capture current input as base before starting
      baseInputRef.current = inputValue;
      recognitionRef.current.start();
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
    // If user types, we switch off voice mode for the next response
    isVoiceInteraction.current = false;
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    // Stop listening immediately to prevent race conditions and provide feedback
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsListening(false);

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: inputValue,
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const resultStream = await sendMessageStream(userMessage.text);
      
      let fullResponseText = '';
      const botMessageId = (Date.now() + 1).toString();

      // Add placeholder bot message
      setMessages(prev => [...prev, {
        id: botMessageId,
        role: 'model',
        text: '',
        isStreaming: true
      }]);

      for await (const chunk of resultStream) {
        const c = chunk as GenerateContentResponse;
        const text = c.text || '';
        fullResponseText += text;

        setMessages(prev => prev.map(msg => 
          msg.id === botMessageId 
            ? { ...msg, text: cleanResponseText(fullResponseText) } 
            : msg
        ));
      }

      // Final processing after stream ends
      setMessages(prev => prev.map(msg => 
        msg.id === botMessageId 
          ? { ...msg, isStreaming: false, text: cleanResponseText(fullResponseText) } 
          : msg
      ));

      // Check for lead data JSON
      const extractedData = extractJsonFromText(fullResponseText);
      if (extractedData) {
        setLeadData(extractedData);
      }

    } catch (error) {
      console.error("Error sending message:", error);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'model',
        text: "I apologize, but I'm having trouble connecting to the server right now. Please try again.",
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  // Silence Detection Effect: Auto-send after 2 seconds of silence
  useEffect(() => {
    let silenceTimer: ReturnType<typeof setTimeout>;

    if (isListening && inputValue.trim()) {
      // Set a timer to send message after 2 seconds of silence
      silenceTimer = setTimeout(() => {
        handleSendMessage();
      }, 2000);
    }

    return () => {
      if (silenceTimer) clearTimeout(silenceTimer);
    };
  }, [inputValue, isListening]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 relative font-sans text-slate-800">
      
      {/* Header */}
      <header className="flex-none bg-razorpay-dark text-white p-4 shadow-md z-10">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className="bg-razorpay-primary p-2 rounded-lg">
                <BotIcon />
             </div>
             <div>
               <h1 className="font-bold text-lg leading-tight">CortexSDR</h1>
               <p className="text-xs text-blue-200 opacity-80">Razorpay Sales Assistant</p>
             </div>
          </div>
        </div>
      </header>

      {/* Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 md:p-6 pb-32">
        <div className="max-w-3xl mx-auto space-y-6">
          
          {messages.map((msg) => (
            <div 
              key={msg.id} 
              className={`flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex max-w-[85%] md:max-w-[75%] gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                
                {/* Avatar */}
                <div className={`flex-none w-8 h-8 rounded-full flex items-center justify-center mt-1 ${
                  msg.role === 'user' 
                    ? 'bg-blue-100 text-razorpay-primary' 
                    : 'bg-razorpay-dark text-white'
                }`}>
                  {msg.role === 'user' ? <UserIcon /> : <BotIcon />}
                </div>

                {/* Bubble */}
                <div className={`p-4 rounded-2xl shadow-sm text-sm md:text-base leading-relaxed whitespace-pre-wrap ${
                  msg.role === 'user'
                    ? 'bg-razorpay-primary text-white rounded-tr-none'
                    : 'bg-white text-slate-700 border border-gray-100 rounded-tl-none'
                }`}>
                  {msg.text}
                  {msg.isStreaming && (
                    <span className="inline-block w-1.5 h-4 ml-1 align-middle bg-slate-400 animate-pulse"></span>
                  )}
                </div>

              </div>
            </div>
          ))}

          {/* Lead Captured Card */}
          {leadData && (
            <div className="flex justify-start w-full animate-fade-in-up">
              <div className="ml-11 max-w-md w-full bg-white border border-green-200 rounded-xl p-5 shadow-lg relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-green-500"></div>
                <div className="flex items-center gap-2 mb-3">
                  <div className="p-1 bg-green-100 rounded-full">
                    <CheckIcon />
                  </div>
                  <h3 className="font-bold text-gray-800">Lead Information Captured</h3>
                </div>
                
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="block text-xs text-gray-400 uppercase tracking-wide">Name</span>
                    <span className="font-medium text-gray-700">{leadData.name || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="block text-xs text-gray-400 uppercase tracking-wide">Company</span>
                    <span className="font-medium text-gray-700">{leadData.company || 'N/A'}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="block text-xs text-gray-400 uppercase tracking-wide">Email</span>
                    <span className="font-medium text-gray-700">{leadData.email || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="block text-xs text-gray-400 uppercase tracking-wide">Role</span>
                    <span className="font-medium text-gray-700">{leadData.role || 'N/A'}</span>
                  </div>
                   <div>
                    <span className="block text-xs text-gray-400 uppercase tracking-wide">Size</span>
                    <span className="font-medium text-gray-700">{leadData.team_size || 'N/A'}</span>
                  </div>
                  <div className="col-span-2">
                     <span className="block text-xs text-gray-400 uppercase tracking-wide">Use Case</span>
                     <span className="font-medium text-gray-700">{leadData.use_case || 'N/A'}</span>
                  </div>
                </div>
                
                <div className="mt-4 pt-3 border-t border-gray-100 text-xs text-gray-400 text-center">
                   Information sent to sales team
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input Area */}
      <div className="flex-none bg-white p-4 border-t border-gray-200">
        <div className="max-w-3xl mx-auto relative flex items-center gap-2">
           <div className="relative flex-grow">
             <input
              type="text"
              value={inputValue}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="Tap microphone to speak..."
              disabled={isLoading || !!leadData}
              className="w-full px-5 py-4 rounded-full border border-gray-300 focus:outline-none focus:border-razorpay-primary focus:ring-2 focus:ring-blue-100 transition-all shadow-sm disabled:bg-gray-100 disabled:text-gray-400"
             />
           </div>
           
           {/* Mic Button - Primary Interaction */}
           <button
             onClick={toggleListening}
             disabled={isLoading || !!leadData}
             className={`flex-none p-4 rounded-full transition-all shadow-md ${
               isListening 
                 ? 'bg-red-50 text-red-500 ring-2 ring-red-400 ring-offset-2 animate-pulse scale-110' 
                 : 'bg-razorpay-primary text-white hover:bg-razorpay-secondary hover:shadow-lg'
             }`}
             title={isListening ? "Listening... (Pause to send)" : "Speak"}
           >
             <MicIcon isListening={isListening} />
           </button>
        </div>
        <div className="text-center mt-2 text-xs text-gray-400">
           {isListening ? "Listening... Pausing for 2s will auto-send." : "AI generated responses. Check company resources for official details."}
        </div>
      </div>

    </div>
  );
};

export default App;